class SkillDot {
    
}